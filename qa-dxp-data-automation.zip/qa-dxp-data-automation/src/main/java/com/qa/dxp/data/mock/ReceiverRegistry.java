package com.qa.dxp.data.mock;

import java.util.Optional;

public interface ReceiverRegistry {

    Optional<Receiver> getReceiver(ReceiverPointer receiverPointer);
}
