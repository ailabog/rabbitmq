package com.qa.dxp.data.mock.exchange;

import com.qa.dxp.data.mock.Receiver;
import com.qa.dxp.data.mock.ReceiverPointer;

import java.util.Map;

public interface MockExchange extends Receiver {
    
    String getType();

    void bind(ReceiverPointer mockQueue, String routingKey, Map<String, Object> arguments);

    void unbind(ReceiverPointer pointer, String routingKey);
}
