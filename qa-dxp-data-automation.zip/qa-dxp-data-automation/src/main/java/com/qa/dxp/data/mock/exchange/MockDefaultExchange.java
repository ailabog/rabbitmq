package com.qa.dxp.data.mock.exchange;

import java.util.Map;

import com.qa.dxp.data.mock.MockNode;
import com.qa.dxp.data.mock.ReceiverPointer;
import com.rabbitmq.client.AMQP;

public class MockDefaultExchange implements MockExchange {

    public static final String TYPE = "default";
    public static final String NAME = "";
    
    private final MockNode node;

    public MockDefaultExchange(MockNode mockNode) {
        this.node = mockNode;
    }

    @Override
    public boolean publish(String previousExchangeName, String routingKey, AMQP.BasicProperties props, byte[] body) {
        return node.getQueue(routingKey).map(q -> q.publish(NAME, routingKey, props, body)).orElse(false);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    @Override
    public void bind(ReceiverPointer receiver, String routingKey, Map<String, Object> arguments) {
        // nothing needed
    }

    @Override
    public void unbind(ReceiverPointer pointer, String routingKey) {
        // nothing needed
    }

    @Override
    public ReceiverPointer pointer() {
        throw new IllegalStateException("No ReceiverPointer (internal use) should be needed for the default exchange");
    }
}
