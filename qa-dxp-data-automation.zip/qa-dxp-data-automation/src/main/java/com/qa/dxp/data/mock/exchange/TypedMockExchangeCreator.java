package com.qa.dxp.data.mock.exchange;

public interface TypedMockExchangeCreator extends MockExchangeCreator {

    String getType();
}
