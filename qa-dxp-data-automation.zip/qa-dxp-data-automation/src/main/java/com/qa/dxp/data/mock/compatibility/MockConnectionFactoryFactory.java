package com.qa.dxp.data.mock.compatibility;

import com.qa.dxp.data.mock.ConfigurableConnectionFactory;
import com.qa.dxp.data.mock.MockConnectionFactory;
import com.qa.dxp.data.mock.tool.Classes;
import com.rabbitmq.client.ConnectionFactory;

/**
 * Factory building a mock implementation of {@link ConnectionFactory} according to the
 * version of **amqp-client** present in the classpath.
 */
public class MockConnectionFactoryFactory {

    public static ConfigurableConnectionFactory<?> build() {
        return build(MockConnectionFactoryFactory.class.getClassLoader());
    }

    public static ConfigurableConnectionFactory<?> build(ClassLoader classLoader) {
        if (Classes.missingClass(classLoader, "com.rabbitmq.client.AddressResolver")) {
            // AddressResolver appears in version 3.6.6 of amqp-client
            // This execution branch is tested in spring-boot integration test with version 1.4.0.RELEASE
            return new MockConnectionFactoryWithoutAddressResolver();
        } else {
            return new MockConnectionFactory();
        }
    }
}
