package com.qa.dxp.data.mock.compatibility;

import com.qa.dxp.data.mock.ConfigurableConnectionFactory;
import com.qa.dxp.data.mock.MockConnection;
import com.qa.dxp.data.mock.metrics.MetricsCollectorWrapper;
import com.rabbitmq.client.Address;
import com.rabbitmq.client.Connection;

import java.util.List;
import java.util.concurrent.ExecutorService;

public class MockConnectionFactoryWithoutAddressResolver extends ConfigurableConnectionFactory<MockConnectionFactoryWithoutAddressResolver> {

    public MockConnectionFactoryWithoutAddressResolver() {
        setAutomaticRecoveryEnabled(false);
    }

    public Connection newConnection(ExecutorService executor, List<Address> addrs, String clientProvidedName) {
        return newConnection();
    }

    public MockConnection newConnection() {
        MetricsCollectorWrapper metricsCollectorWrapper = MetricsCollectorWrapper.Builder.build(this);
        MockConnection mockConnection = new MockConnection(mockNode, metricsCollectorWrapper);
        return mockConnection;
    }
}
