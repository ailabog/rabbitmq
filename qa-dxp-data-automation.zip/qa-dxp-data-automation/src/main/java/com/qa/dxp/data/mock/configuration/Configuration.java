package com.qa.dxp.data.mock.configuration;

import java.util.LinkedHashMap;
import java.util.Map;

import com.qa.dxp.data.mock.exchange.MockExchangeCreator;
import com.qa.dxp.data.mock.exchange.TypedMockExchangeCreator;

public class Configuration {
    private Map<String, MockExchangeCreator> additionalExchangeCreatorsByType = new LinkedHashMap<>();

    public Configuration registerAdditionalExchangeCreator(TypedMockExchangeCreator mockExchangeCreator) {
        additionalExchangeCreatorsByType.put(mockExchangeCreator.getType(), mockExchangeCreator);
        return this;
    }

    public MockExchangeCreator getAdditionalExchangeByType(String type) {
        return additionalExchangeCreatorsByType.get(type);
    }
    
    public boolean isAdditionalExchangeRegisteredFor(String type) {
        return additionalExchangeCreatorsByType.containsKey(type);
    }
}
