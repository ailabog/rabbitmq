package com.qa.dxp.data.mock.apis;

import com.qa.dxp.data.mock.utils.connectors.RestAssuredConnector;
import com.qa.dxp.data.mock.utils.general.ConfigUtils;
import com.qa.dxp.data.mock.utils.general.ConfigUtils.ConfigKeys;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeTest;


import java.util.HashMap;
import java.util.Map;

import static org.testng.Assert.assertEquals;

/**
 * Create Report POST API call negative
 */

public class API_CreateReportNegativeTest {
    protected static final Logger logger = LoggerFactory.getLogger(API_CreateReportNegativeTest.class);
    private String DATE = "09-09-2023";
    private String NETWORK = "AMC";
    private String APP = "android";
    private String TYPE = "invalid event";
    private String REASON = "unplanned";
    private String EVENT = "xxxxxxx";
    private Integer COUNT = 1500;
    private RestAssuredConnector connector = new RestAssuredConnector();

    private String requestBody;
    private String requestUri;

    @BeforeTest
    public void setupData() {
        PostReportCreateModel requestMessageBody = new PostReportCreateModel();
        requestMessageBody.setDate(DATE);
        requestMessageBody.setNetwork(NETWORK);
        requestMessageBody.setApp(APP);
        requestMessageBody.setType(TYPE);
        requestMessageBody.setReason(REASON);
        requestMessageBody.setEvent(EVENT);
        requestMessageBody.setCount(COUNT);
        requestBody = requestMessageBody.toString();
        requestUri = ConfigUtils.getProperty(ConfigKeys.BASE_URL.toString()) + ConfigUtils.getProperty(ConfigKeys.END_URL_REPORT.toString());
    }

    @Test
    public void createPostOrderTest() {
        Map<String, String> requestHeaders = new HashMap<String, String>();
        requestHeaders.put("accept", " application/json");
        requestHeaders.put("Content-Type", "application/json");
        Response someResponse = connector.postRequest(requestUri, requestHeaders, requestBody);
        logger.info("requestUri" + requestUri + "" + "requestBody: " + requestBody);
        logger.info("Response: " + someResponse.getBody().asString());
        assertEquals(someResponse.getStatusCode(), 400);
    }

    @Test
    public void createPostOrderMissingHeaderTest() {
        Map<String, String> requestHeaders = new HashMap<String, String>();
        Response someResponse = connector.postRequest(requestUri, requestHeaders, requestBody);
        logger.info("requestUri" + requestUri + "" + "requestBody: " + requestBody);
        logger.info("Response: " + someResponse.getBody().asString());
        assertEquals(someResponse.getStatusCode(), 415);
    }
}
