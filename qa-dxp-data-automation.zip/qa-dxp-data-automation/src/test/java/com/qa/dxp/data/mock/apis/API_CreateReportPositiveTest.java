package com.qa.dxp.data.mock.apis;

import com.qa.dxp.data.mock.utils.connectors.RestAssuredConnector;
import com.qa.dxp.data.mock.utils.general.ConfigUtils;
import com.qa.dxp.data.mock.utils.general.ConfigUtils.ConfigKeys;
import com.qa.dxp.data.mock.utils.general.GenerateRandomDataUtils;
import io.restassured.response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

public class API_CreateReportPositiveTest {
    protected static final Logger logger = LoggerFactory.getLogger(API_CreateReportPositiveTest.class);

    public static final String DATENOW = "14-09-2023";
    public static final String NETWORK = "AMC";
    public static final String APP = "android";
    public static final String TYPE = "invalid event";
    public static final String REASON = "unplanned";
    public static final String EVENT = "xxxxxxx";
    public static final Integer COUNT = 1500;

    private RestAssuredConnector connector = new RestAssuredConnector();

    private String requestBody;
    private String requestUri;

    @BeforeTest
    public void setupData() {
        PostReportCreateModel requestMessageBody = new PostReportCreateModel();
        requestMessageBody.setDate(DATENOW);
        requestMessageBody.setNetwork(NETWORK);
        requestMessageBody.setApp(APP);
        requestMessageBody.setType(TYPE);
        requestMessageBody.setReason(REASON);
        requestMessageBody.setEvent(EVENT);
        requestMessageBody.setCount(COUNT);
        requestBody = requestMessageBody.toString();
        requestUri = ConfigUtils.getProperty(ConfigKeys.BASE_URL.toString()) + ConfigUtils.getProperty(ConfigKeys.END_URL_REPORT.toString());
    }

    @Test
    public void createPostOrderTest() {
        Map<String, String> requestHeaders = new HashMap<String, String>();
        requestHeaders.put("accept", " application/json");
        requestHeaders.put("Content-Type", "application/json");
        Response someResponse = connector.postRequest(requestUri, requestHeaders, requestBody);
        logger.info("requestUri" + requestUri + "" + "requestBody: " + requestBody);
        logger.info("Response: " + someResponse.getBody().asString());
        assertEquals(someResponse.getStatusCode(), 200);
    }
}

